# Vehicle Parking Management System

![Tests](https://github.com/YOUR_USERNAME/vehicle-parking-management-system/actions/workflows/tests.yml/badge.svg)
![Python](https://img.shields.io/badge/python-3.8%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)

A beginner-friendly, menu-driven Python console application that manages vehicles entering and leaving a parking facility. It assigns slots automatically, records entry times, calculates parking charges, and keeps everything in a local SQLite database so records survive between runs.

> **Course:** Python Essentials - Fall Semester 2026-2027
> **Author:** Krishna Singh (Reg. No. 26BEC11076)

## Features

- **Park a vehicle** - records vehicle number, owner and type; assigns the first free slot; rejects duplicates.
- **Remove a vehicle** - calculates duration and fee, prints a bill, frees the slot.
- **Search** - look up a parked vehicle by its number.
- **Display** - list all parked vehicles (slot order) or the status of every slot.
- **Statistics** - total / occupied / available slots and occupancy rate.
- **Persistent** - data is stored in `parking.db` (SQLite).

## Getting started

Requires **Python 3.8+**. No external packages are needed.

```bash
git clone https://github.com/YOUR_USERNAME/vehicle-parking-management-system.git
cd vehicle-parking-management-system
python main.py
```

`parking.db` is created automatically on first run with 20 parking slots.

## Parking charges

| Vehicle type | Rate |
|--------------|------|
| Bike  | Rs. 10 / hour |
| Car   | Rs. 20 / hour |
| Other | Rs. 30 / hour |

Minimum charge is one hour; partial hours are rounded **up** with `math.ceil()`. Example: a car parked for 2.2 hours is billed for 3 hours = Rs. 60.

## Sample session

```text
==================================================
      VEHICLE PARKING MANAGEMENT SYSTEM
==================================================
1. Park Vehicle
2. Remove Vehicle
3. Search Vehicle
4. Display Parked Vehicles
5. Display Parking Slots
6. Parking Statistics
7. Exit

Enter your choice: 1

--- PARK VEHICLE ---
Enter vehicle number: MP04AB1234
Enter owner name: Rahul

Vehicle Types:
1. Bike
2. Car
3. Other
Select vehicle type: 2

Vehicle parked successfully!
Vehicle Number : MP04AB1234
Owner Name     : Rahul
Vehicle Type   : Car
Parking Slot   : 1
Entry Time     : 2026-09-19 14:30:00
```

```text
--- PARKING BILL ---
Vehicle Number : MP04AB1234
Owner Name     : Rahul
Vehicle Type   : Car
Parking Slot   : 1
Entry Time     : 19-09-2026 14:30:00
Exit Time      : 19-09-2026 16:42:00
Duration       : 2.2 hours
Parking Fee    : Rs. 60
```

## Project structure

```text
vehicle-parking-management-system/
├── main.py              # Console menu / user interface
├── parking.py           # Business logic + SQLite access
├── tests/
│   └── test_parking.py  # Unit tests (unittest)
├── docs/
│   └── DESIGN.md        # Architecture, schema, diagrams
├── .github/workflows/
│   └── tests.yml        # CI: runs tests on every push
├── requirements.txt
├── LICENSE
└── README.md
```

## Architecture

| Layer | File | Role |
|-------|------|------|
| Presentation | `main.py` | Menus, prompts, formatted output |
| Business logic | `parking.py` | Entry, removal, billing, search, statistics |
| Data access | SQLite | `parking_slots` and `vehicles` tables |

See [docs/DESIGN.md](docs/DESIGN.md) for the schema and workflow diagrams.

## Running the tests

```bash
python -m unittest discover -s tests -v
```

## Future enhancements

- Store historical parking sessions instead of deleting them on exit
- GUI with Tkinter / CustomTkinter
- Admin login and role-based access
- Multiple parking floors
- Digital receipts and QR-code entry
- Dashboards and charts for statistics
- Online reservations
- Automatic number-plate recognition

## License

Released under the [MIT License](LICENSE).
